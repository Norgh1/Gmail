//
//  ViewController.swift
//  Gmail
//
//  Created by Norayr on 11.07.23.
//

import UIKit

class SignInViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    
    @IBAction func signInTapped(_ sender: Any) {
        fetchAddAccountVC()
    }
    
}

