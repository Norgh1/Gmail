//
//  Cordiantor.swift
//  Gmail
//
//  Created by Norayr on 11.07.23.
//

import Foundation
import UIKit


//MARK: - TODO

final class Cordiantor: UIViewController {

    static let shared = Cordiantor()
    
    
}

