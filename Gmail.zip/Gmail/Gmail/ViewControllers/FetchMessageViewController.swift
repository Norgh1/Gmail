//
//  FetchMessageViewController.swift
//  Gmail
//
//  Created by Norayr on 11.07.23.
//

import Foundation
import UIKit




final class FetchMessageViewController: UIViewController {
    
    @IBOutlet weak var tableView: UITableView!
    
    override func viewDidLoad() {
        configureTableViewMessages()
        super.viewDidLoad()
    }
    
    @IBAction func slideButton(_ sender: Any) {
    }
    
    
}
