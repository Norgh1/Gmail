//
//  AddAccountViewController.swift
//  Gmail
//
//  Created by Norayr on 11.07.23.
//


import UIKit
import Foundation

final class AddAccountViewController: UIViewController {
    
    
    @IBOutlet weak var tableView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        configureDataSourseDelegate()
    }
    
    
    @IBAction func dissmissAddAccountVC(){
        self.dismiss(animated: true)
    }
}
