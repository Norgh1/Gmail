//
//  ExtensionFetchAllMessageVC.swift
//  Gmail
//
//  Created by Norayr on 11.07.23.
//

import Foundation
import UIKit

//MARK: - TableView Extension for FetchMessageViewController


extension FetchMessageViewController: UITableViewDataSource, UITableViewDelegate {
    
    func configureTableViewMessages() {
        self.tableView.delegate = self
        self.tableView.dataSource = self
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        MessageModel.userNameLabel.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "messagecell", for: indexPath) as! MessageTableViewCell
        cell.userNameLabel.text = MessageModel.userNameLabel[indexPath.row]
        cell.userMessageDate.text = MessageModel.userMessageDate[indexPath.row]
        cell.userMessageLabe.text = MessageModel.userMessage[indexPath.row]
        cell.userMessageSubject.text = MessageModel.subjectMessage[indexPath.row]
        cell.userImage.image = UIImage(named: MessageModel.userImage[indexPath.row])
        return cell
    }
    
}
