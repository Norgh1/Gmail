//
//  ExtensionSignIn.swift
//  Gmail
//
//  Created by Norayr on 11.07.23.
//

import Foundation
import UIKit


//MARK: - Extensions for SignInViewController

extension SignInViewController {
    
    func fetchAddAccountVC() {
        
        let vc = storyboard?.instantiateViewController(identifier: "addaccaount") as! AddAccountViewController
        vc.modalPresentationStyle = .fullScreen
        present(vc, animated: true)
        
    }
}


//MARK: - TODO, must implement alertcontrollers 

extension SignInViewController {
    
     func alertControllerForVisitor(){
        let alert = UIAlertController(title: "dsfg", message: "", preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "dsf", style: .default))
        present(alert, animated: true)
    }
    
}

