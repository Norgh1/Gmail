//
//  ExtensionAddAccountVC.swift
//  Gmail
//
//  Created by Norayr on 11.07.23.
//

import UIKit
import Foundation


//MARK: - TableView Extension for FetchMessageViewController

extension AddAccountViewController: UITableViewDelegate, UITableViewDataSource {
    
    //MARK: - Configure TableView

    func configureDataSourseDelegate(){
        self.tableView.dataSource = self
        self.tableView.delegate = self
        self.tableView.reloadData()
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        ServiceModel.image.count
    }
    
    //MARK: - This is not good solution, but aneway.
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! AddAccountTableViewCell
        cell.serviceLabel.text = ServiceModel.label[indexPath.row]
        cell.serviceImageView.image = UIImage(named: ServiceModel.image[indexPath.row])
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        switch indexPath.row {
        case -1...0:
            DispatchQueue.main.async {
                let vc = self.storyboard?.instantiateViewController(identifier: "fetchvc") as! FetchMessageViewController
                vc.modalPresentationStyle = .overFullScreen
                self.navigationController?.popToRootViewController(animated: true)
                self.present(vc, animated: true)
            }
            print("Here is corrent row \(indexPath.row)")
        case 1...3:
            print("Here is corrent row \(indexPath.row)")
        default:
            break
        }
    }
    
}
