//
//  MessageModel.swift
//  Gmail
//
//  Created by Norayr on 11.07.23.
//

import Foundation
import UIKit

struct MessageModel: Codable {
    
    static var userNameLabel = ["Job.am","Staff.am","stackoverfloww.com","medium.com","github.com","list.am","Facbook Notification","swift.org","Instagram","Matteo Manferdini","John Weck"]
    static var userImage = ["job.am","staff.am","stackoverfloww.com","medium.com","github.com","list.am","Facbook Notification","swift.org","Instagram","Matteo Manferdini","John Weck"]
    static var userMessage = ["Was certainty remaining engrossed applauded sir how discovery","Settled opinion how enjoyed greater joy adapted too shy","Doubtful for answered one fat indulged margaret sir shutters together","Ladies so in wholly around whence in at. Warmth he up giving oppose if. Impossible is dissimilar entreaties oh on terminated","Earnest studied article country ten respect showing had","But required offering him elegance son improved informed.","Supplied directly pleasant we ignorant ecstatic of jointure so if","Lorem Ipsum comes from a latin text written in 45BC by Roman statesman","The most common form of Lorem ipsum is the following.Random Text Generator is a web application which provides true random text which you can use in your documents or web designs","It's better than Lorem ipsum because it can produce text in many languages and in particular","Also when you use plain Lorem ipsum text, your design will look like a million other designs out there","which truly means nothing.", "I'm trying at least 6 of these Hello! tips"]
    static var userMessageDate = ["Jun 12","Apr 1","Dec 10","March 23","May 4","Jul 18","Sep 19","Jun 12","Apr 1","Dec 10","March 23","May 4","Jul 18","Sep 19","Jun 12","Apr 1","Dec 10","March 23","May 4","Jul 18","Sep 19","Jun 12","Apr 1","Dec 10","March 23","May 4","Jul 18","Sep 19"]
    static var subjectMessage = ["Let us work on your For example for just 30 days","Give me 20 minutes and I'll give you For example", "Are you still wasting money on Hello! (without anything to show for it)?","Answered: your most burning questions about Hello!","Do Hello! like Mister Rogers","Now you can have Hello! without the work","How to do Hello! like a boss","I'm trying at least 6 of these Hello! tips","The ultimate guide to email", "Let us work on your For example for just 30 days","Give me 20 minutes and I'll give you For example", "Are you still wasting money on Hello! (without anything to show for it)?","Answered: your most burning questions about Hello!","Do Hello! like Mister Rogers","Now you can have Hello! without the work","How to do Hello! like a boss","I'm trying at least 6 of these Hello! tips","The ultimate guide to email"]
    
    var userNameLabel: String
    var userMessageLabel: String
    var userImage: String
    var messageDate = Date()
    
}
