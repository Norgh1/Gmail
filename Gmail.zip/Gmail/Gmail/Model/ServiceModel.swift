//
//  ServiceModel.swift
//  Gmail
//
//  Created by Norayr on 11.07.23.
//

import Foundation

//MARK: -  Can be recive data from network for example

struct ServiceModel: Codable {
    
    static var label = ["Google","iCloud","Office365","Outlook","Yahoo","Other"]
    static var image = ["google", "icloud","office365","outlook","yahoo","other"]
    
    //MARK: can be many other proprites to recive 
    var serviceImage: String
    var serviceLabel: String
    
}
