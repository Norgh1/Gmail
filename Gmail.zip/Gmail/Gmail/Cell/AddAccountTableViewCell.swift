//
//  AddAccountTableViewCell.swift
//  Gmail
//
//  Created by Norayr on 11.07.23.
//

import UIKit

class AddAccountTableViewCell: UITableViewCell {

    @IBOutlet weak var serviceImageView: UIImageView!    
    @IBOutlet weak var serviceLabel: UILabel!
    
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        serviceImageView.layer.cornerRadius = contentView.alpha
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }

}
