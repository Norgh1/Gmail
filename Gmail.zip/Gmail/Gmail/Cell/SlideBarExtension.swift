//
//  SlideBarExtension.swift
//  Gmail
//
//  Created by Norayr on 11.07.23.
//

import Foundation
import SideMenu

final class SlideMenu: SideMenuNavigationController {
    
    var customSideMenuManager = SideMenuManager()
    
    override init(rootViewController: UIViewController, settings: SideMenuSettings = SideMenuSettings()) {
        super.init(rootViewController: rootViewController)
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        
        customSideMenuManager.rightMenuNavigationController = .none
        //customSideMenuManager.menuPresentMode.backgroundColor = .white
    }
    
}
