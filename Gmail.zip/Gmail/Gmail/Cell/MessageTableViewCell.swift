//
//  MessageTableViewCell.swift
//  Gmail
//
//  Created by Norayr on 11.07.23.
//

import UIKit

class MessageTableViewCell: UITableViewCell {

    @IBOutlet weak var userNameLabel: UILabel!
    @IBOutlet weak var userMessageLabe: UILabel!
    @IBOutlet weak var userImage: UIImageView!
    @IBOutlet weak var userMessageDate: UILabel!
    @IBOutlet weak var userMessageSubject: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        userImage.layer.cornerRadius = 25
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
    }
}
